# APP FORGE — Android Cloud V2

Convierte un proyecto web (HTML/CSS/JS) en una aplicación Android APK mediante compilación en la nube.

1. Sube este proyecto a tu repositorio APP-FORGE.
2. Coloca el proyecto que quieras convertir dentro de `project/`.
3. Debe existir `project/index.html`.
4. GitHub → Actions → `APP FORGE — Build Android` → Run workflow.
5. Al terminar, descarga el artefacto `APP-FORGE-Android`.
