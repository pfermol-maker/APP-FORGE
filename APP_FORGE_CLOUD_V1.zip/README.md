# APP FORGE — Cloud V1

Flujo: proyecto web → compilación Windows → instalador .exe.

Uso desde móvil:
1. Crea un repositorio nuevo en GitHub.
2. Sube el contenido de esta carpeta.
3. Coloca el proyecto a convertir dentro de `project/`.
4. Comprueba que exista `project/index.html`.
5. Abre Actions y ejecuta `APP FORGE — Build Windows`.
6. Al terminar, descarga el artefacto `APP-FORGE-Windows`.

La compilación se realiza en un runner Windows de GitHub Actions.
